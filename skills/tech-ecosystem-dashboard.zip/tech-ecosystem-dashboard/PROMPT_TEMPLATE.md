# Tech Ecosystem Dashboard Prompt Template

Use this template when you want the `tech-ecosystem-dashboard` skill to generate a dense, poster-style architecture blueprint instead of a generic dashboard.

## How To Use

Choose one of these two modes:

1. **Minimal Mode**: fastest input, good when you only need a solid first draft
2. **Blueprint Mode**: richer input, best when you want NVIDIA-style information density

---

## Minimal Mode

Copy this and fill in the blanks:

```md
请基于 tech-ecosystem-dashboard skill，为我生成一张单屏 HTML 技术架构蓝图。

主题标题：
一句话价值主张：

核心流程（4-6步）：
1.
2.
3.
4.

核心架构层：
- 
- 
- 
- 

主要应用场景：
- 
- 
- 

基础设施 / 底座层：
- 
- 
- 

希望风格：
- Enterprise Dark / Clean Light / 品牌定制

补充要求：
- 参考 NVIDIA CAE 这种高密度 poster
- 输出单文件 HTML
- 不要做成普通 admin dashboard
```

---

## Blueprint Mode

Copy this when you want a much stronger result:

```md
请基于 tech-ecosystem-dashboard skill，生成一张高密度、单屏、企业级技术蓝图海报，输出为单文件 HTML。
参考风格：NVIDIA CAE / enterprise architecture poster / industrial schematic。

# 1. 基本信息
主题标题：
副标题：
一句话价值主张：
目标受众：
使用场景：

# 2. 顶部价值区
希望展示的 4-6 个关键价值 / KPI / 优势：
- 
- 
- 
- 

# 3. 左侧流程区
典型工作流 / 生命周期 / 处理流程（4-6步）：
1.
2.
3.
4.
5.

每一步可补充：输入、动作、输出、关键约束

# 4. 中央视图区
核心平台 / 核心架构 / 核心引擎分层：
- 第1层：
- 第2层：
- 第3层：
- 第4层：

可补充的结构化信息：
- 协议 / schema / interface：
- 核心模块 / capability taxonomy：
- 数据流 / 控制流：
- guardrails / governance：

# 5. 右侧场景区
主要输出 / 应用场景 / 业务落地面：
- 
- 
- 
- 

每个场景可补充：目标用户、价值、结果形态

# 6. 底部基础区
基础设施 / 部署 / 集成生态 / 依赖：
- 运行时：
- 存储与状态：
- 工具与集成：
- 知识与数据：
- 安全与治理：

# 7. 底部补充区
如适用，请加入这些模块中的 2-3 个：
- 生态 / 伙伴 / 集成矩阵
- 用例与收益表格
- 部署模式
- 路线图 / Future Trends
- 闭环运营 / Loop Diagram

# 8. 视觉要求
主题风格：
主色：
辅助色：
是否深色：
是否需要图标：是
是否需要 table / matrix / workflow / loop：

# 9. 强约束
- 必须是单屏 poster，不要长页面
- 必须高密度，不要空卡片
- 至少包含 4 种不同组件类型
- 中心区必须是最密的
- 不要使用 emoji
- 输出单文件 HTML
```

---

## Recommended Input Strategy

If you want stable high-quality output, provide information in this priority order:

1. title + value proposition
2. 4-6 workflow steps
3. core platform layers
4. application scenarios
5. foundation / infrastructure
6. benefits / ecosystem / roadmap
7. visual direction

If you only provide a title, the model can still generate something, but it will never be as strong as a properly filled blueprint brief.

---

## Hermes Agent Example

```md
请基于 tech-ecosystem-dashboard skill，生成一张高密度单屏 HTML 架构蓝图，主题是 Hermes Agent。
参考风格：NVIDIA CAE 这种 enterprise dark poster。

主题标题：Hermes Agent Runtime Blueprint
副标题：Structured Planning, Tool Execution, Grounded Delivery
一句话价值主张：通过规划、工具调用、状态回写与知识补强，实现可控的多步任务执行。
目标受众：AI 产品、平台架构、工程团队

顶部价值区：
- Faster task delivery
- Structured tool use
- Better grounding
- Lower manual orchestration cost
- Safer multi-step execution

左侧流程区：
1. Request Intake
2. Plan / Clarify / Route
3. Execution Context Assembly
4. Tool Execution Loop
5. Artifact / State Update
6. Deliver / Terminate

中央视图区：
- Planner Policy Layer
- Prompt / Protocol Contract Layer
- Execution Spine
- Capability Matrix
- Observation & State Layer
- Guardrail Layer

协议 / schema / interface：
- ChatML
- JSON planner output
- tool signatures
- MCP bindings
- task state updates

右侧场景区：
- Automation operations
- Document generation
- Tool orchestration
- Knowledge grounding
- Collaborative tasking

底部基础区：
- FastAPI runtime
- Scheduler
- SQLAlchemy session and models
- Workspace storage
- Knowledge bases
- Skill registry
- MCP resolver and adapter

底部补充区：
- Ecosystem & Integration Fabric
- Example Use Cases & Benefits table
- Technology Roadmap & Future Focus

视觉要求：
- enterprise dark
- NVIDIA-like green accent
- single-screen poster
- mixed components: KPI strip, workflow ladder, platform matrix, scenario panel, table, roadmap loop

强约束：
- 不要普通 dashboard
- 不要大面积留白
- 中心区必须最密
- 输出单文件 HTML
```

---

## Anti-Pattern Prompts

These inputs usually produce weak results:

```md
帮我画一个 Hermes Agent 架构图
```

```md
做一个酷炫一点的 AI dashboard
```

```md
参考 NVIDIA 风格，随便出一版
```

They fail because they do not provide enough information structure.

---

## Fast Fill Checklist

Before sending your prompt, make sure you have at least:

- a title
- a one-line value proposition
- 4 workflow steps
- 4 architecture layers
- 3 application scenarios
- 3 foundation items
- a theme direction
